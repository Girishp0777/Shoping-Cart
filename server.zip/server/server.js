const express = require('express');
const dotenv = require('dotenv').config();
const cookieparser=require('cookie-parser');
const path = require('path');
app=express();


const connectionDB=require('./db');
const seller=require('./Routers/Seller/sellerRouter');
const product=require('./Routers/Product/productRouter');
const user=require('./Routers/User/userRouter');
const cart=require('./Routers/Cart/cartRouter');
const address=require('./Routers/User/userAddressRouter');
const order=require('./Routers/Order/orderRouter');
//const { request } = require('http');
const mail=require('./Routers/Mail/mailRouter'); 
const otp=require('./Routers/Otp/otpRouter');
const dash=require('./Routers/Seller/dashboardRouter');

port=5000;


connectionDB()
app.use(express.json());
app.use(cookieparser());

app.use('/api/seller',seller);

app.use('/api/product',product);

app.use('/api/user',user);

app.use('/api/cart',cart);

app.use('/api/address',address);

app.use('/api/order',order);

app.use('/api/mail',mail);

app.use('/api/otp',otp);

app.use('/api/dashboard',dash);



app.use(express.static(path.join(__dirname, 'public')));

app.use(express.static(path.join(__dirname, 'Product')));

app.listen(port, ()=> console.log("Server Connected Sucessfully", port));