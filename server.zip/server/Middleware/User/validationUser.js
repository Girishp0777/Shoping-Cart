const jwt=require('jsonwebtoken')
const cookie=require('cookie-parser')


const verifyToken= async(req, res, next)=>{
    const cookie= req.headers.cookie;
    const token= cookie?.split("=")[1];

    jwt.verify(token, process.env.JWT_SECRET_KEY,(error ,newuser)=>{
        if(error){
            if(error.name === 'TokenExpiredError'){
                return res.status(401).json({message:"Token Expired",newuser});
            }
            return res.status(401).json({message:"Invalid Token",});   
        }
        console.log("Decoded User:",newuser.id)
        req.newuser=newuser.id;
        next();
    });
};



module.exports=verifyToken;