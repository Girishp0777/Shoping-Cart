const jwt=require('jsonwebtoken')

const verifyToken = async (req, res, next) => {
    const cookie = req.headers.cookie;
    const token = cookie?.split("=")[1];
   
    jwt.verify(token, process.env.JWT_SECRET_KEY, (error,newseller) => {
      if (error) {
        if (error.name === 'TokenExpiredError') {
          return res.status(401).json({message: "Token has expired",newseller});
        }
        return res.status(401).json({message: "Invalid token"});
      }
      console.log("Decoded user:",newseller.id);
      req.newseller = newseller.id;
      next();
    });
  };


  module.exports=verifyToken;