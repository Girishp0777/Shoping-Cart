const jwt=require('jsonwebtoken')

const refreshtoken = (req, res, next) => {
    const cookie= req.headers.cookie;
    const pretoken = cookie?.split("=")[1];
   
    if (!pretoken) {
      console.log(pretoken);
      res.status(404).json({message: "couldn't find token"});
    }
   
    jwt.verify(String(pretoken), process.env.JWT_SECRET_KEY,(error,newseller) => {
      if (error) {
        return res.status(400).json({message: "invalid token",});
    }
   
      res.clearCookie(`${newseller.id}`);
      req.cookies[`${newseller.id}`] ="";
   
      const token = jwt.sign({id:newseller.id},process.env.JWT_SECRET_KEY, {
        expiresIn: '1m',
      });
   
      console.log("regenerated token :",token);
   
      res.cookie(String(newseller.id), token, {
        path: "/",
        expires: new Date(Date.now() + 1000*9600),
        httpOnly: true,
        sameSite: "lax",
      });
   
      req.newseller = newseller.id;
      next();
    });
  };

  module.exports=refreshtoken;