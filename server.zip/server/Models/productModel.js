const mongoose=require('mongoose')


const productSchema=mongoose.Schema({
    Seller_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"seller",
        required:true
    },
    Title:{
        type:String,
        required:true 
    },
    Sub_title:{
        type:String,
        required:true
    },
    Mrp:{
        type:String,
        required:true,
    },
    Discount_Price:{
        type:String,
        required:true
    },
    Total_Cost:{
        type:String,
        required:true
    },
    Product_Number:{
        type:String,
        required:true
    },
    Categories:{
        type:String,
        required:true
    },
    Sub_Categories:{
        type:String,
        required:true
    },
    Image1: {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        }
    },
    Image2: {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        }
    },
    Image3: {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        }
    },
    Image4: {
        data:
        {
          type:Buffer,
        },
        contentType:
        {
          type:String,
        },
        path:
        {
          type:String,
        }
    }
})


module.exports=mongoose.model("product",productSchema,'product')