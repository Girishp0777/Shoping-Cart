const mongoose=require('mongoose')

const cartSchema=mongoose.Schema({
    User_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user",
        required:true
    },
    Product_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"product",
        required:true
    }
});

module.exports=mongoose.model("cart",cartSchema,'cart');