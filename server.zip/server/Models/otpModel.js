const mongoose =require('mongoose')

const otpSchema= mongoose.Schema({
    Email:{
        type:String
    },
    otp:{
        type:String
    },
    expiration:{
        type:Date
    }
})
module.exports=mongoose.model('Otp',otpSchema,"Otp")