const mongoose=require('mongoose')


const userAddress=mongoose.Schema({
    First_Name:{
        type:String,
        required:true
    },
    Last_Name:{
        type:String,
        required:true
    },
    Mobile:{
        type:String,
        maxlength:10,
        minlength:10,
        required:true
    },
    Address_1:{
        type:String,
        required:true
    },
    City:{
        type:String,
        required:true
    },
    State:{
        type:String,
        required:true
    },
    Pincode:{
        type:String,
        required:true
    },
    OrderNumber:{
        type:String,
        required:true
    },
    OrderDate:{
        type:String,
        required:true
    }
});

module.exports=mongoose.model("userAddress",userAddress, 'userAddress');
