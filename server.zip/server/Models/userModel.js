const mongoose=require('mongoose')

const userSchema= mongoose.Schema({
    First_Name:{
        type:String,
        required:true
    },
    Last_Name:{
        type:String,
        required:true
    },
    Mobile:{
        type: String,
        validate: {
        validator: function(value) {
            return /\d{10}/.test(value);
            },
            message: props => `${props.value} is not a valid phone number!`
        },
        required: [true, 'User phone number required']
    },
    Email: {
        type:String,
        required:[true,"Please Enter the email"],
        Unique: [true,"this email is already exists"],
        lowercase:true,
        trim:true,
        validate:{
            validator:function(value){
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
            },
            message: props => `${props.value} is a not valid Address`
 
        },
    },
    Password:{
        type:String,
        required:true
    }
});

module.exports=mongoose.model("user", userSchema, 'user')