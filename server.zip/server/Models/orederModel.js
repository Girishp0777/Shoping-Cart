const mongoose=require('mongoose')

const OrderSchema=mongoose.Schema({
    User_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user",
        required:true
    },
    Product_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"product",
        required:true
    },
    userAddress_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"userAddress",
        required:true
    }
});

module.exports=mongoose.model("oreder",OrderSchema,'order');