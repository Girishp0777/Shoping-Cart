const express =require('express')
const router=express.Router()
const {getsellers, getusers, getproducts, getorder}= require('../../Controller/Seller/dashboard');
const verifyToken=require('../../Middleware/Seller/validationSeller');




router.route('/seller').get(getsellers);
router.route('/user').get(getusers);
router.route('/product').get(getproducts);
router.route('/order').get(getorder);

      


module.exports=router;