const express =require('express')
const router=express.Router()
const {sellerget, seller_update, sellerbyid ,seller_delete}=require('../../Controller/Seller/sellerCrud')
const {register, login, logout, currentadmin}=require('../../Controller/Seller/sellerAuth')
const verifyToken=require('../../Middleware/Seller/validationSeller')
const refreshtoken=require('../../Middleware/Seller/ValidationRefresh')




router.route('/register').post(register);
router.route('/login').post(login);
router.route('/logout').post(logout);
router.route('/current').get(verifyToken, refreshtoken, currentadmin);



router.route('/')
      .get( verifyToken, sellerget);

router.route('/:id')
      .get(sellerbyid)
      .put(seller_update)
      .delete(seller_delete)
      


module.exports=router;