const express=require('express')
const router=express.Router();
const {getcart, cartPost, getidcart, updatecart, deletecart, getAggregatedData}=require('../../Controller/Cart/cartCrud');
const validation=require('../../Middleware/User/validationUser');

router.route('/')
      .get(getcart)
      .post(validation, cartPost);

router.route('/getdata').get(getAggregatedData);

router.route('/:id')
      .get(getidcart)
      .put(validation, updatecart)
      .delete(validation, deletecart);


module.exports=router;

