const express=require('express')
const router=express.Router();

const { getaddress, addresspost, getId, updateaddres, deleteAddress}=require('../../Controller/User/userAddress');
const validation=require('../../Middleware/User/validationUser');


router.route('/')
      .get(getaddress)
      .post(validation, addresspost);

router.route('/:id')
      .get(getId)
      .put(validation, updateaddres)
      .delete(validation, deleteAddress);

module.exports=router;