const express= require('express')
const router= express.Router();
const {register, login, currentuser, logout, forgetPassword} =require('../../Controller/User/userAuth');
const {userget, getbyId, userupdate, deleteuser}=require('../../Controller/User/userCrud');
const validation=require('../../Middleware/User/validationUser');

router.route('/register').post(register);

router.route('/login').post(login);

router.route('/current').get(validation, currentuser);

router.route('/logout').post(logout);

router.route('/forgetpassword').post(forgetPassword);



router.route('/')
      .get(userget);

router.route('/:id')
      .get(getbyId)
      .put(userupdate)
      .delete(deleteuser);
      

module.exports=router;


