const express= require('express')
const router= express.Router();
const mailler=require('../../Controller/Mail/mailController');



router.route('/').post(mailler);

      

module.exports=router;