const express=require('express')
const router=express.Router();
const {getorder, orderPost, getidorder, updateorder, deleteorder, getAggregatedData}=require('../../Controller/Order/orderCrud');
const validation=require('../../Middleware/User/validationUser');

router.route('/')
      .get(getorder)
      .post(validation, orderPost);

router.route('/getdata').get(getAggregatedData);

router.route('/:id')
      .get(getidorder)
      .put(validation, updateorder)
      .delete(validation, deleteorder);


module.exports=router;

