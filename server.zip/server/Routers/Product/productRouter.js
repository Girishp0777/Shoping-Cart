const express=require('express')
const router=express.Router();
const {getproduct, productbyID, createProduct, updateProduct, deleteProduct}=require('../../Controller/Product/productCrud')
const validation= require('../../Middleware/Seller/validationSeller')


router.route('/')
      .get(getproduct)
      .post(validation, createProduct);

router.route('/:id')
      .get(productbyID)
      .put(updateProduct)
      .delete(deleteProduct);
    

module.exports=router;