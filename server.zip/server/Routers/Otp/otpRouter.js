const express=require('express');
const router=express.Router();
const {getotp, validate}=require('../../Controller/Otp/otpController');


router.route('/getotp').post(getotp)
router.route('/validate').post(validate);


module.exports=router;