const bcrypt=require('bcrypt')
const jwt=require('jsonwebtoken')
const nodemailer = require("nodemailer")
const user=require('../../Models/userModel')

const register=  async(req, res)=>{
try{
    const First_Name=req.body.First_Name;
    const Last_Name=req.body.Last_Name;
    const Mobile=req.body.Mobile;
    const Email=req.body.Email;
    const Password=req.body.Password;

    const existingUser=await user.findOne({Email});
    if(existingUser){
        res.status(400).json({message:"This Email Id is Already Exists"});
    }

    const isStrongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/.test(Password);
    if (!isStrongPassword) {
        return res.status(400).json({ message: "Password is not strong enough" });
    }
    else{
    const hashedPassword= await bcrypt.hash(Password, 10);
    const newuser= new user({
        First_Name,
        Last_Name,
        Mobile,
        Email,
        Password:hashedPassword

    });
    await newuser.save();
    console.log(newuser);

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.Mail,
        pass: process.env.Pass,
      },
      secure: false, // Use false for TLS
      port: 587, // Use port 587 for TLS
    });
    

    const mailoptions = {
      from: {
        name: "My Shop",
        address: process.env.Mail,
      },
      to: Email,
      subject: "Successfully sent mail",
      text: "Hello! how are you",
    };
    
    await transporter.sendMail(mailoptions);
    console.log("Mail sent successfully..!");
    return res.status(200).json({ message: "Data inserted successfully", newuser });
}
}
catch(error){
    console.error('Error creatin error:', error);
    res.status(500).json({message:"Internal Server Error",error});
}
}

const login =async(req,res)=>{
  const Email=req.body.Email;
  const Password=req.body.Password;

  const existinguser = await user.findOne({Email});
  if (!existinguser) {
    return res.status(400).json({message: "User Not Found Please Register"});
  }


  const newuser = await user.findOne({ Email });
  const isPassword = await bcrypt.compare(Password,newuser.Password);
  if (!isPassword) {
      return res.status(400).json({message: "Incorrect Email id or Password......."});
    }
    const accesstoken = jwt.sign(
      {
        id: newuser._id,
      },
      process.env.JWT_SECRET_KEY,
      {
        expiresIn: '15m',
      }
    );
   console.log("token is generated\n", accesstoken);
   
    if (req.cookies[`${newuser._id}`]) {
      req.cookies[`${newuser._id}`] = " ";
    }
   
    res.cookie(String(newuser._id), accesstoken, {
      path: "/",
      expires: new Date(Date.now() + 1000 *900),
      httpOnly: true,
      sameSite: "lax",
    });
    return res.status(200).json({message: "successfully logged in",newuser,accesstoken});
}

const currentuser= async(req,res)=>{
  const Users=req.newuser;
  try{
   const current= await user.findById(Users, "-Password");
    if(!current){
      res.status(404).json({message:"User Not Found"});
    }
    else{
      res.status(200).json(current);
    }
  }
  catch(error){
    return res.status(500).json({message:"Internal Server Error"});
  }
}


const logout=async(req, res,)=>{
  const cookie=req.headers.cookie;
  const accesstoken =cookie?.split("=")[1];


  if(!accesstoken)
  {
    return res.status(404).json({message:"Invalid Token"});
  }

  jwt.verify(accesstoken, process.env.JWT_SECRET_KEY, (error,newuser)=>{
    if (error) {
      return res.status(400).json({message: "invalid token or token empty"});
    }

    res.clearCookie(`${newuser.id}`);
    req.cookies[`${newuser.id}`] = "";

    return res.status(200).json({message: "successfully logged out"});
  });
}


const forgetPassword= async(req, res)=>{
  try{
    const Email=req.body.Email;
    const Password=req.body.Password;
    const Users=await user.findOne({Email});
  if(!Users){
    res.status(404).json({message:"User Not Found"});
  }
  else{
    const hashedPassword= await bcrypt.hash(Password, 10); 
    const updatedpassword= await user.findOneAndUpdate(
      req.params.id,
      {
      Password:hashedPassword
      }
      );
    res.status(200).json({message:"Updated Sucessfully", updatedpassword})
  }
  
}
catch(error){
  res.status(500).json({message:"Internal Server Error",error});
  console.log(error);
}
}



module.exports={register, login, currentuser, logout, forgetPassword};