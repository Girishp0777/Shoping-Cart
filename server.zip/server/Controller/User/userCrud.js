const user=require('../../Models/userModel')


const userget=async(req, res)=>{
    try{
       const User= await user.find();
       res.status(200).json({User});
    }
    catch(error){
        res.status(500).json({message:"Internal Server Error"});
    }
};


const getbyId= async(req, res)=>{
    try{
       const User= await user.findById(req.params.id);
       if(!User){
        res.status(404).json({message:"Id Not Found"});
       }
       else{
        res.status(200).json({User});
       }
    }
    catch(error){
         res.status(500).json({message:"Internal Server Error"});
    }
};


const userupdate= async(req, res)=>{
    try{
       const Updated= await user.findByIdAndUpdate(
        req.params.id,
        req.body,
        {new:true});
        
        if(!Updated){
            return res.status(404).json({message:"Id Not Found"});
        }
        else{
            return res.status(200).json(Updated);
        }
    }
    catch(error){
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deleteuser= async(req, res)=>{
try{
    const User=await user.findByIdAndDelete(req.params.id);
    if(!User){
        res.status(404).json({message:"Id Not Found"});
    }
    else{
        res.status(200).json(User);
    }
  }
  catch(error){
    return res.status(500).json({message:"Internal Server Error"});
  }
};

module.exports={userget, getbyId, userupdate, deleteuser}