const address=require('../../Models/userAddressModel');

const getaddress=async(req,res)=>{
    try{
        const userAddress= await address.find();
        if(!userAddress){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
        res.status(200).json(userAddress);
        }
    }
    catch(error){
        console.log(error);
        res.status(500).json({message:"Internal server Error",error});
    }
};


const addresspost=async(req,res)=>{
    try{
        const newAddress= new address(req.body);
        await newAddress.save().then((newAddress)=>{
            res.status(200).json(newAddress);
        })
    }
    catch(error){
        res.status(500).json({message:"Internal Server Error",error});
    }
};

const getId=async(req,res)=>{
    try{
        const userAddres=await address.findById(req.params.id);
        if(!userAddres){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(userAddres);
        }
    }
    catch(error){
        res.status(500).json({message:"Inernal server Error",error});
    }
};

const updateaddres=async(req,res)=>{
    try{
        const useradrress=await address.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true}
        );

        if(!useradrress){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(useradrress);
        }
    }
    catch(error){
        res.status(500).json({message:"Internal Server Error",error});
    }
};

const deleteAddress=async(req,res)=>{
    try{
    const addressdelte=await address.findByIdAndDelete(req.params.id);
    if(!addressdelte){
        res.status(404).json({message:"Id Not Found"});
    }
    else{
        res.status(200).json(addressdelte);
    }
    }
    catch(error){
        res.status(500).json({message:"Internal Server Error",error});
    }
};


module.exports={getaddress, addresspost, getId, updateaddres, deleteAddress};