const nodemailer = require("nodemailer");
require("dotenv").config();

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: 'girishpgiri60961@gmail.com',
    pass: 'sgoh kydx eiiw ifov',
  },
  secure: false, // Use false for TLS
  port: 587, // Use port 587 for TLS
});

const mailoptions = {
  from: {
    name: "Washateria",
    address: 'girishpgiri60961@gmail.com',
  },
  to: 'siripireddythulasi11@gmail.com',
  subject: "Successfully sent mail",
  text: "Hello! how are you",
};

const sendMail = async (req, res) => {
  try {
    await transporter.sendMail(mailoptions);
    console.log("Mail sent successfully..!");
  } catch (error) {
    console.log(error);
  }
};

// Uncomment the line below if you want to send the mail immediately
// sendMail(mailoptions);

module.exports = sendMail;
