const multer = require('multer');
const path = require('path');
const bcrypt = require('bcrypt');
const seller=require('../../Models/sellerModel')



const sellerget=async(req,res)=>
{
  try
  {
    const Seller=await seller.find().exec();
    res.json(Seller);
  }
  catch(error)
  {
    console.log("cannot find data from database");
  }
}


const sellerbyid=async(req,res)=>{
    try
    {
      const Seller=await seller.findById(req.params.id);
      if(!Seller)
      {
        res.status(404).json({'error':"sorry id is not found"});
      }
      else{
        res.json(Seller);
      }
    }
    catch{
        res.status(500).json({"error":"Internal server error"});
      }
  };



  const storage = multer.diskStorage({
    destination: path.join("public/Images"),
    filename: function (req, file, cb) {
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
  });
  
  const fileFilter = (req, file, cb) => {
    const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedFileTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: fileFilter,
  }).fields([
    { name: "Adhar_card", maxCount: 1 },
    { name: "Outlet_image", maxCount: 1 },
    { name: "Register_image", maxCount: 1 },
  ]);
  
  const seller_update = async (req, res) => {
    const Seller = await seller.findById(req.params.id);

    if (!Seller) {
        res.status(404).json({ message: "Seller not found" });
        return;
    }
    upload(req, res, async (err) => {
        if (err) {
            console.log("Multer error", err);
            return res.status(400).json({ error: "File uploading failed" });
        }

        if (!req.files || !req.files.Adhar_card || !req.files.Outlet_image || !req.files.Register_image) {
            return res.status(400).json({ error: "Adhar_card or Outlet_image not selected" });
        }

        const Adhar_card = {
            data: req.files.Adhar_card[0].buffer,
            contentType: req.files.Adhar_card[0].mimetype,
            path: path.join("public", "Images", req.files.Adhar_card[0].filename),
        };

        const Outlet_image = {
            data: req.files.Outlet_image[0].buffer,
            contentType: req.files.Outlet_image[0].mimetype,
            path: path.join("public", "Images", req.files.Outlet_image[0].filename),
        };

        const Register_image = {
          data: req.files.Register_image[0].buffer,
          contentType: req.files.Register_image[0].mimetype,
          path: path.join("public", "Images", req.files.Register_image[0].filename),
      };


        console.log("Images uploaded successfully");

        const newupdated = await seller.findByIdAndUpdate(
            req.params.id,
            req.body,
            req.file,
            {
            Adhar_card,
            Outlet_image,
            Register_image
          },
          { new: true}
         );

        console.log('Product Updated:', newupdated);
        return res.status(201).json(newupdated);
    });
};


const seller_delete=async(req,res)=>
{
    try
    {
      const Seller=await seller.findById(req.params.id);
      if(!Seller)
      {
        res.status(404).json({'error':"sorry id is not found"});
      }
      else{
        await seller.findByIdAndDelete(req.params.id);
        res.status(200).json({"message":"products delete"});
      }
    }
    catch{
      console.log(seller);
        res.status(500).json({"error":"Internal server error"});
      }  
}; 


module.exports={sellerget, seller_update, sellerbyid ,seller_delete};