require('dotenv').config()
const bcrypt=require('bcrypt')
const multer = require('multer');
const path = require('path');
const jwt=require('jsonwebtoken')
const seller=require('../../Models/sellerModel')

const storage = multer.diskStorage({
  destination: path.join("public/Images"),
  filename: function (req, file, cb) {
      cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  if (allowedFileTypes.includes(file.mimetype)) {
      cb(null, true);
  } else {
      cb(null, false);
  }
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 },
  fileFilter: fileFilter,
}).fields([
  { name: "Adhar_card", maxCount: 1 },
  { name: "Outlet_image", maxCount: 1 },
  { name: "Register_image", maxCount: 1 },
]);

const register = async (req, res, next) => {
  try {
      upload(req, res, async (err) => {

              if (err) {
                  console.log("Multer error", err);
                  return res.status(400).json({ error: "File uploading failed" });
              }

              if (!req.files || !req.files.Adhar_card || !req.files.Outlet_image || !req.files.Register_image ) {
                  return res.status(400).json({ error: "Images or Images1 not selected" });
              }

              const Adhar_card = {
                  data: req.files.Adhar_card[0].buffer,
                  contentType: req.files.Adhar_card[0].mimetype,
                  path: path.join("public", "Images", req.files.Adhar_card[0].filename),
              };

              const Outlet_image = {
                  data: req.files.Outlet_image[0].buffer,
                  contentType: req.files.Outlet_image[0].mimetype,
                  path: path.join("public", "Images", req.files.Outlet_image[0].filename),
              };
              
              const Register_image = {
                data: req.files.Register_image[0].buffer,
                contentType: req.files.Register_image[0].mimetype,
                path: path.join("public", "Images", req.files.Register_image[0].filename),
            };
              console.log("Images uploaded successfully");

              const { First_Name, Last_Name, Email, Mobile, Gst, Outlet_Name, Outlet_Address_1, Outlet_Address_2, Outlet_City, Outlet_State, Outlet_Pincode,  Password } = req.body;
              const existingSeller = await seller.findOne({ Email });
              const hashedPassword = await bcrypt.hash(Password, 10); 
              if (existingSeller) {
                  return res.status(400).json({ message: "User already exists. Try a different email id" });
              }


              const newseller = new seller({
                First_Name, Last_Name, Email, Mobile, Gst, Outlet_Name, Outlet_Address_1, 
                Outlet_Address_2, Outlet_City, Outlet_State, Outlet_Pincode,
                Password:hashedPassword,
                Adhar_card:Adhar_card,
                Outlet_image:Outlet_image,
                Register_image:Register_image

              });

              await newseller.save();
              console.log(newseller);
              return res.status(200).json({ message: "Data inserted successfully", newseller });
      });
  } catch (error) {
      console.error('Error creatin Seller:', error);
      return res.status(500).json({ message: "Internal server error" });
  }
};



const login =async(req,res)=>{
    const Email=req.body.Email;
    const Password=req.body.Password;

    const existingSeller = await seller.findOne({Email});
    if (!existingSeller) {
      return res.status(400).json({message: "Seller Not Found Please Register"});
    }


    const newseller = await seller.findOne({ Email });
    const isPassword = await bcrypt.compare(Password,newseller.Password);
    if (!isPassword) {
        return res.status(400).json({message: "Incorrect Email id or Password......."});
      }
      const accesstoken = jwt.sign(
        {
          id: newseller._id,
        },
        process.env.JWT_SECRET_KEY,
        {
          expiresIn: '15m',
        }
      );
     console.log("token is generated\n", accesstoken);
     
      if (req.cookies[`${newseller._id}`]) {
        req.cookies[`${newseller._id}`] = " ";
      }
     
      res.cookie(String(newseller._id), accesstoken, {
        path: "/",
        expires: new Date(Date.now() + 1000 *900),
        httpOnly: true,
        sameSite: "lax",
      });
      return res.status(200).json({message: "successfully logged in",newseller,accesstoken});
}



const currentadmin = async (req, res, next) => {
const userId=req.newseller;
  try
  {
    current = await seller.findById( userId, "-password");
  } 
  catch (error) {
    console.log(error);
    return res.status(500).json({message: "Internal server error"});
  }
  if (!current) 
  {
    return res.status(404).json({message: "User not found"});
  }
  return res.status(200).json({current});
};
 

const logout = (req, res, next) => {
  const cookie = req.headers.cookie;
  const accesstoken = cookie?.split("=")[1];
 
  if (!accesstoken) {
    res.status(404).json({message: "couldn't find token"});
  }
 
  jwt.verify(String(accesstoken), process.env.JWT_SECRET_KEY, (error,newseller) => {
    if (error) {
      return res.status(400).json({message: "invalid token or token empty"});
    }
 
    res.clearCookie(`${newseller.id}`);
    req.cookies[`${newseller.id}`] = "";
 
    return res.status(200).json({message: "successfully logged out"});
  });
};


module.exports={register, login, currentadmin, logout};