const seller= require('../../Models/sellerModel')
const user= require('../../Models/userModel')
const product= require('../../Models/productModel')
const order= require('../../Models/orederModel')


const getsellers= async(req,res)=>{
    try{
        const Seller= await seller.countDocuments();
        res.status(200).json({message:"Number of Sellers",Seller})
    }
    catch(error)
    {
        res.status(500).json({message:"Internal Server Error",error})
    }
}

const getusers= async(req,res)=>{
    try{
        const User= await user.countDocuments();
        res.status(200).json({message:"Number of Users",User})
    }
    catch(error)
    {
        res.status(500).json({message:"Internal Server Error",error})
    }
}

const getproducts= async(req,res)=>{
    try{
        const Product= await product.countDocuments();
        res.status(200).json({message:"Number of Products",Product})
    }
    catch(error)
    {
        res.status(500).json({message:"Internal Server Error",error})
    }
}


const getorder= async(req,res)=>{
    try{
        const Order= await order.countDocuments();
        res.status(200).json({message:"Number of Orders",Order})
    }
    catch(error)
    {
        res.status(500).json({message:"Internal Server Error",error})
    }
}


module.exports={getsellers, getusers, getproducts, getorder}