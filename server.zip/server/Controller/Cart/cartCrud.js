const cart=require('../../Models/cartModel')


const getcart=async(req, res)=>{
    try{
        const Cart= await cart.find();
        if(!Cart){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Cart);
        }

    }
    catch(error){
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const cartPost=async(req, res)=>{
    try{
    const Product_id=req.body.Product_id;
    const Cart=new cart({
        Product_id,
        User_id:req.newuser
    });
    await Cart.save().then((Cart)=>{
        res.status(200).json(Cart);
    });
    }
    catch(error){
        console.log(error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const getidcart=async(req, res)=>{
    try{
        const Cart= await cart.findById(req.params.id);
        if(!Cart){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Cart);
        }
    }
    catch(error){
        return res.status(500).json({messagre:"Internal Server Error"});
    }
};


const updatecart=async(req, res)=>{
    try{
        const Cart= await cart.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true});
        if(!Cart){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Cart);
        }  
    }
    catch(error){
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deletecart=async(req, res)=>{
    try{
        const Cart= await cart.findByIdAndDelete(req.params.id);
        if(!Cart){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Cart);
        }
    }
    catch(error){
        return res.status(500).json({message:"Internal Server Error"});
    }
}


async function getAggregatedData(req, res) {
    try {
    const aggregateResult = await cart.aggregate([
    {
      $lookup: {
        from: 'user',
        localField: 'User_id',
        foreignField: '_id',
        as: 'users'
      }
    },
    {
      $unwind: '$users'
    },
    {
      $lookup: {
        from: 'product',
        localField: 'Product_id',
        foreignField: '_id',
        as: 'products'
      }
    },
    {
      $unwind: '$products'
    },
    {
      $project: {
        _id: 0,
        Title: '$products.Title',
        Sub_title: '$products.Sub_title',
        Sub_Categories: '$products.Sub_Categories',
        Discount_Price: '$products.Discount_Price',
        Mrp: '$products.Mrp',
        Total_Cost: '$products.Total_Cost'
      }
    }
    ]);
    
    console.log(aggregateResult);
    res.json(aggregateResult);
    } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
    }
    }




module.exports={getcart, cartPost, getidcart, updatecart, deletecart, getAggregatedData };