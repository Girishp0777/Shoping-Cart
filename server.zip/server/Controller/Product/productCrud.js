const multer = require('multer');
const path = require('path');
const product =require('../../Models/productModel')



const getproduct=async(req,res)=>{
    try{
        const Product = await product.find()
        res.status(200).json(Product);
    }
    catch(Error){
        res.status(500).json({message:"Internal Server Error",Error});
    }
}


const productbyID = async(req,res)=>{
    try{
        const Product= await product.findById(req.params.id)
        if(!Product){
            res.status(404).json({message:"Product Not Found"});
        }
        res.send(Product);
    }
    catch(Error){
        res.status(500).json({message:"Internal Server Error",Error});
    }
}



const storage = multer.diskStorage({
    destination: path.join("Product/Images"),
    filename: function (req, file, cb) {
        cb(null, file.fieldname + Date.now() + path.extname(file.originalname));
    }
  });
  
  const fileFilter = (req, file, cb) => {
    const allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedFileTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: fileFilter,
  }).fields([
    { name: "Image1", maxCount: 1 },
    { name: "Image2", maxCount: 1 },
    { name: "Image3", maxCount: 1 },
    { name: "Image4", maxCount: 1 },

  ]);


const createProduct= async(req,res)=>{
    try {
        upload(req, res, async (err) => {
  
                if (err) {
                    console.log("Multer error", err);
                    return res.status(400).json({ error: "File uploading failed" });
                }
  
                if (!req.files || !req.files.Image1 || !req.files.Image2 || !req.files.Image3 || !req.files.Image4  ) {
                    return res.status(400).json({ error: "Image1 or Image2, Image3, Image4 not selected" });
                }
  
                const Image1 = {
                    data: req.files.Image1[0].buffer,
                    contentType: req.files.Image1[0].mimetype,
                    path: path.join("Product", "Images", req.files.Image1[0].filename),
                };
  
                const Image2 = {
                    data: req.files.Image2[0].buffer,
                    contentType: req.files.Image2[0].mimetype,
                    path: path.join("Product", "Images", req.files.Image2[0].filename),
                };
                
                const Image3 = {
                  data: req.files.Image3[0].buffer,
                  contentType: req.files.Image3[0].mimetype,
                  path: path.join("Product", "Images", req.files.Image3[0].filename),
              };

              const Image4 = {
                data: req.files.Image4[0].buffer,
                contentType: req.files.Image4[0].mimetype,
                path: path.join("Product", "Images", req.files.Image4[0].filename),
            };
                console.log("Images uploaded successfully");


            const {Title, Sub_title, Mrp, Discount_Price, Product_Number,
                Categories, Sub_Categories} =req.body

                const dp= Mrp*Discount_Price;
            
                const total = Mrp-dp;
                const Product=new product({
                    Title, 
                    Sub_title, 
                    Mrp, 
                    Discount_Price, 
                    Total_Cost:total,
                    Product_Number,
                    Categories, 
                    Sub_Categories,
                    Image1:Image1, 
                    Image2:Image2,
                    Image3:Image3,
                    Image4:Image4,
                    Seller_id:req.newseller});
                await Product.save().then((Product) =>{
                 res.status(200).json({message:"Product Created Sucessfullt",Product});
                 
                });

        });

    }
    catch(Error){
        res.status(500).json({message:"Internal Server Error",Error});
        console.log(Error);
    }    
}




const updateProduct= async(req, res)=>{
    try{
        const Product= await product.findById(req.params.id)
        if(!Product){
            res.status(404).json({message:"Id Not Found"});
        }
        upload(req, res, async (err) => {
  
            if (err) {
                console.log("Multer error", err);
                return res.status(400).json({ error: "File uploading failed" });
            }

            if (!req.files || !req.files.Image1 || !req.files.Image2 || !req.files.Image3 || !req.files.Image4  ) {
                return res.status(400).json({ error: "Image1 or Image2, Image3, Image4 not selected" });
            }

            const Image1 = {
                data: req.files.Image1[0].buffer,
                contentType: req.files.Image1[0].mimetype,
                path: path.join("Product", "Images", req.files.Image1[0].filename),
            };

            const Image2 = {
                data: req.files.Image2[0].buffer,
                contentType: req.files.Image2[0].mimetype,
                path: path.join("Product", "Images", req.files.Image2[0].filename),
            };
            
            const Image3 = {
              data: req.files.Image3[0].buffer,
              contentType: req.files.Image3[0].mimetype,
              path: path.join("Product", "Images", req.files.Image3[0].filename),
          };

          const Image4 = {
            data: req.files.Image4[0].buffer,
            contentType: req.files.Image4[0].mimetype,
            path: path.join("Product", "Images", req.files.Image4[0].filename),
        };
            console.log("Images uploaded successfully");


        const updated = await product.findByIdAndUpdate(
            req.params.id,
            req.body,
            req.files,
            Image1,
            Image2,
            Image3,
            Image4,
            {new:true}
            );

            res.status(200).send(updated);
    })
    }catch(Error){
        res.status(500).json({message:"Internal Server Error",Error});
        console.log(Error);
    }
}


const deleteProduct= async(req,res)=>{
    try{
        const Product= await product.findById(req.params.id)
        if(!Product){
            res.status(404).json({message:"Id Not Found"});
        }

        const Products =await product.findByIdAndDelete(req.params.id)
        res.status(200).json("Deleted Sucessfully",Products)
    }
    catch(Error){
        res.status(500).json({message:"Internal Server Error",Error});
        console.log(Error);
    }
}


module.exports={getproduct, productbyID, createProduct, updateProduct, deleteProduct}