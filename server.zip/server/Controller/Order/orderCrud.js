const order=require('../../Models/orederModel')


const getorder=async(req, res)=>{
    try{
        const Order= await order.find();
        if(!Order){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Order);
        }

    }
    catch(error){
        console.log(error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const orderPost=async(req, res)=>{
    try{
    const Product_id=req.body.Product_id;
    const userAddress_id=req.body.userAddress_id;
    const Order=new order({
        Product_id,
        userAddress_id,
        User_id:req.newuser
    });
    await Order.save().then((Order)=>{
        res.status(200).json(Order);
    });
    }
    catch(error){
        console.log(error);
        return res.status(500).json({message:"Internal Server Error"});
    }
};

const getidorder=async(req, res)=>{
    try{
        const Order= await order.findById(req.params.id);
        if(!Order){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Order);
        }
    }
    catch(error){
        return res.status(500).json({messagre:"Internal Server Error"});
    }
};


const updateorder=async(req, res)=>{
    try{
        const Order= await order.findByIdAndUpdate(
            req.params.id,
            req.body,
            {new:true});
        if(!Cart){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Order);
        }  
    }
    catch(error){
        return res.status(500).json({message:"Internal Server Error"});
    }
};


const deleteorder=async(req, res)=>{
    try{
        const Order= await order.findByIdAndDelete(req.params.id);
        if(!Order){
            res.status(404).json({message:"Id Not Found"});
        }
        else{
            res.status(200).json(Order);
        }
    }
    catch(error){
        return res.status(500).json({message:"Internal Server Error"});
    }
}


async function getAggregatedData(req, res) {
    try {
    const aggregateResult = await order.aggregate([
    {
      $lookup: {
        from: 'user',
        localField: 'User_id',
        foreignField: '_id',
        as: 'users'
      }
    },
    {
      $unwind: '$users'
    },
    {
      $lookup: {
        from: 'product',
        localField: 'Product_id',
        foreignField: '_id',
        as: 'products'
      }
    },
    {
      $unwind: '$products'
    },
    {
        $lookup: {
          from: 'userAddress',
          localField: 'userAddress_id',
          foreignField: '_id',
          as: 'userAddresses'
        }
      },
      {
        $unwind: '$userAddresses'
      },
    {
      $project: {
        _id: 0,
        First_Name: '$userAddresses.First_Name',
        Last_Name: '$userAddresses.Last_Name',
        Mobile:'$userAddresses.Mobile',
        Address_1:'$userAddresses.Address_1',
        City:'$userAddresses.City',
        State:'$userAddresses.State',
        Pincode:'$userAddresses.Pincode',
        OrderNumber:'$userAddresses.OrderNumber',
        OrderDate:'$userAddresses.OrderDate',
        Title: '$products.Title',
        Sub_title: '$products.Sub_title',
        Sub_Categories: '$products.Sub_Categories',
        Discount_Price: '$products.Discount_Price',
        Mrp: '$products.Mrp',
        Total_Cost: '$products.Total_Cost'
      }
    }
    ]);
    
    console.log(aggregateResult);
    res.json(aggregateResult);
    } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
    }
    }




module.exports={getorder, orderPost, getidorder, updateorder, deleteorder, getAggregatedData };