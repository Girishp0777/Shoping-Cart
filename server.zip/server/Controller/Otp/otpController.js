const nodemailer = require("nodemailer")
const otpp = require('../../Models/otpModel')
const user=require('../../Models/userModel')

const getotp=async(req,res)=>{
try{
    const code = Math.floor(999+Math.random()* 1000);
    console.log(code);
    const expiration =new Date(Date.now()+ 500000)
    const Email=req.body.Email;
    const Otp =new otpp({
        Email,
        otp:code,
        expiration
    })
    await Otp.save();

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: process.env.Mail,
          pass: process.env.Pass,
        },
        secure: false, // Use false for TLS
        port: 587, // Use port 587 for TLS
      });
      
  
      const mailoptions = {
        from: {
          name: "My Shop",
          address: process.env.Mail,
        },
        to: Email,
        subject: "Successfully sent mail",
        text: `Your Otp Code is:${code}`,
      };
      
      await transporter.sendMail(mailoptions);
      console.log("Mail sent successfully..!");
    res.status(200).json({Otp});
}
catch(error){
    res.status(500).json({message:"Internal Server Error",error});
    console.log(error);
}
}

const validate= async(req,res)=>{
try{
    const ootp=req.body.ootp;
    const Eemail=req.body.Email;
    const Mail= await user.findOne({Email:Eemail});
    const code= await otpp.findOne({otp:ootp , expiration: { $gt : new Date()}});
    if(!Mail){
        res.status(404).json({message:"User Not Found"});
    }
    if(code){
       res.status(200).json({valid:true});
       await otpp.findOneAndDelete({otp:ootp});
    }
    else{
        res.status(404).json({valid:false});
    }
}
catch(error){
    res.status(500).json({message:"Internal Server Error",error});
    console.log(error);
}
}


module.exports={ getotp, validate};